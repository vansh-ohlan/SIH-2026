# Bhu Setu — Pitch Deck Content

## Slide 1 — Title
**Bhu Setu**  
An Integrated GIS-based Digital Public Infrastructure for Land Governance  
SIH 2026 • Problem Statement 26014

## Slide 2 — Problem
Land governance involves RoR, cadastral maps, registration, land use, master plans, permissions, restrictions, taxation and utilities. These information sources may be maintained by different departments and systems.

The challenge is not simply digitization. Citizens and officials need a useful, parcel-level view across relevant information.

## Slide 3 — Existing Ecosystem
- **DILRMP:** land-record modernization and integration objectives
- **NGDRS:** property/document registration
- **Bhu-Naksha:** cadastral/parcel map management
- **State land-record services:** citizen access to land records and services

**Positioning:** Bhu Setu complements these systems rather than replacing them.

## Slide 4 — Gap
Bhu Setu targets:
- Parcel-centric integration
- GIS + textual information in one context
- Common schema with state-specific adapters
- Cross-record consistency and anomaly support
- Simpler citizen and officer workflows
- Planning/service context around the parcel

## Slide 5 — Solution
Bhu Setu provides:
1. Georeferenced parcel layer
2. Parcel identifier such as ULPIN where available
3. Integration and normalization layer
4. Unified parcel profile
5. Citizen portal
6. Revenue/registration dashboards
7. Rule/AI-assisted anomaly flags
8. Audit and access controls

## Slide 6 — Architecture
**Authorized sources → API/data exchange → Integration & normalization → Parcel-centric data layer → GIS/citizen/officer interfaces → Decision support → Human review**

Production integration would depend on authorized APIs, data-sharing agreements and applicable governance.

## Slide 7 — Demo
1. Search a parcel
2. Select it on GIS
3. Open the unified parcel profile
4. View relevant linked records
5. Show an area/attribute inconsistency flag
6. Route it to an authorized officer workflow

The prototype can use mock/sample datasets if real government APIs are not available.

## Slide 8 — AI / Decision Support
Example:
- RoR area = 2.50 ha
- GIS area = 2.10 ha
- Difference exceeds configured tolerance
- Bhu Setu flags the parcel for officer review

AI/rules assist verification. They do not decide legal ownership.

## Slide 9 — Impact
**Citizens:** simpler access, transparency, less portal-hopping  
**Officials:** faster verification and better parcel context  
**Government:** interoperability, analytics, planning support and scalable infrastructure

## Slide 10 — Feasibility
- Mock/sample data for prototype
- Common schema + state adapters
- Standard geospatial formats
- Authentication + RBAC + audit trail
- Modular architecture for additional states/departments
- Authorized APIs and governance for production

## Slide 11 — Likely Judge Questions
**Q1. What is new when DILRMP/NGDRS/Bhu-Naksha already exist?**  
Bhu Setu complements them with a parcel-centric integration layer, unified GIS experience and decision-support workflow.

**Q2. How will you handle different state formats?**  
A common schema and state-specific adapters map local fields, units and formats into a common model.

**Q3. Can AI decide ownership?**  
No. It only flags anomalies. Legal decisions remain with authorized officials.

## Slide 12 — Closing
**Bhu Setu: Make the land parcel the common context.**

Connect relevant information → Visualize it on GIS → Flag inconsistencies → Help people act.
