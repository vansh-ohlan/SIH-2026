# Bhu Setu — SIH 2026 Problem Statement 26014

**Project:** Bhu Setu  
**Problem Statement:** 26014 — An Integrated GIS-based Digital Public Infrastructure for Land Governance

Bhu Setu is proposed as a parcel-centric, GIS-enabled integration layer that connects relevant authorized land-governance information into a unified experience.

## Core positioning

Bhu Setu does **not** replace DILRMP, NGDRS, Bhu-Naksha or state land-record systems. It builds on the existing ecosystem by connecting relevant information around the land parcel.

## Main value

- Unified parcel-centric GIS view
- Integration/normalization of relevant authorized records
- Citizen and officer workflows
- Cross-record consistency/anomaly flags
- Human-in-the-loop decision support
- Scalable architecture using common schemas and state-specific adapters

See the other files in `docs/` for research, gap analysis, pitch content, script and judge Q&A.
