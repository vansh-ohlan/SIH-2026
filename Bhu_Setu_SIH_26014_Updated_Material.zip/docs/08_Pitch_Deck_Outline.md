# SIH 26014 — Pitch Deck Outline

1. Title — Bhu Setu
2. Problem — fragmented land information and workflows
3. Existing Ecosystem — DILRMP, NGDRS, Bhu-Naksha, state services
4. Gap — parcel-centric integration and decision support
5. Solution — GIS-first Bhu Setu
6. Architecture — sources → APIs/normalization → parcel layer → interfaces → decision support
7. Demo — search → map → profile → flag → action
8. AI / Decision Support — anomaly flags with human review
9. Impact — citizens, officials, government
10. Feasibility & Scalability — common schema + state adapters
11. Judge Questions — 3 likely questions with answers
12. Closing — make the parcel the common context
