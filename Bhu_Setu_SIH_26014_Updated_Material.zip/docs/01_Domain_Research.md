# SIH 26014 — Domain Research

## 1. Overview

Indian land governance involves multiple categories of information, including:

- Record of Rights (RoR)
- Cadastral / parcel maps
- Property registration records
- Land use information
- Master plans
- Building permissions
- Restrictions
- Property taxation
- Utility infrastructure
- Revenue and related administrative information

Different government initiatives already digitize and modernize important parts of this ecosystem. The SIH 26014 opportunity is therefore not simply to digitize land records again, but to improve interoperability, parcel-centric access, GIS visualization and decision support across relevant authorized information sources.

---

# 2. DILRMP

## Full Form
**Digital India Land Records Modernization Programme**

## What is it?
DILRMP is a Government of India programme under the Department of Land Resources (DoLR) for modernization and digitization of land records and development of an integrated land information management ecosystem.

The current DoLR document repository lists **DILRMP 3.0 Operational Guidelines (2026–2031)**.

## Main objectives
DILRMP aims to:

- modernize land-record management
- provide more reliable and accessible land information
- reduce land disputes
- help check fraudulent transactions
- reduce repeated physical visits
- support information sharing among relevant agencies
- support better land-resource planning
- integrate textual and spatial land information

## Major components
Important components include:

1. Computerization of Record of Rights (RoR)
2. Digitization of cadastral maps
3. Integration of textual RoR with spatial cadastral maps
4. Computerization of registration
5. Integration of registration and land records
6. Survey / resurvey
7. Modern record rooms
8. Revenue court / case management related digitization
9. Capacity building and programme management

## Key understanding
DILRMP is a **broad government programme/mission**, not simply one website or one application.

---

# 3. RoR and Cadastral Maps

## Record of Rights (RoR)
RoR is primarily textual information about rights/interests associated with a land parcel. Exact fields vary by state.

Example:

- Parcel/Khasra number
- Owner/right holder information
- Area
- Land-related classification

## Cadastral Map
A cadastral map is the spatial representation of land parcels and their boundaries.

### Easy memory
**RoR tells us WHAT/WHO.**

**Cadastral/GIS data tells us WHERE.**

This distinction is important for the proposed GIS-based platform.

---

# 4. NGDRS

## Full Form
**National Generic Document Registration System**

## What is it?
NGDRS is a DoLR initiative for property/document registration.

## Objectives
The official NGDRS portal describes objectives including:

- One Nation One Software
- a generic platform for property/document registration
- citizen empowerment through online services
- a common platform for registration stakeholders

## Features
NGDRS includes features such as:

- online document entry
- property valuation
- stamp duty calculation
- role-based access
- citizen alerts
- e-KYC/authentication features
- maker/checker workflows
- storage of registered documents
- certified-copy related functionality
- linking with land-record systems
- local-language support

## Key understanding
**NGDRS = registration side of the land-governance ecosystem.**

Important: NGDRS already supports linkage with land records. Therefore, our pitch should not claim that registration and land records are completely disconnected.

---

# 5. Bhu-Naksha

## What is it?
Bhu-Naksha is an Indian cadastral mapping solution developed for parcel map management.

The official Bhu-Naksha portal describes it as a comprehensive tool for parcel-map management for authorized officials of States/UTs.

## Main purpose
It supports digital management of cadastral/parcel maps and is designed to support changes to parcel maps arising from mutations.

## Key understanding
**Bhu-Naksha = cadastral / parcel map management.**

It is different from DILRMP:

- DILRMP = broad modernization programme
- Bhu-Naksha = specific cadastral mapping solution/tool

---

# 6. Bhulekh

## What does Bhulekh mean?
"Bhulekh" is commonly used for state-level digital land-record access/services. It should not be presented as one single uniform national database.

State implementations and names can differ.

## Example: Punjab
The official Punjab Land Records portal provides services/searches such as:

- View Jamabandi
- Owner-name-wise search
- Khewat-wise search
- Khasra-wise search
- Khatouni-wise search
- Mutation information
- Roznamcha/Rapat information
- Registered deed information
- Fard-related services
- Online land-record services

## Key understanding
**Bhulekh = state-level digital land-record access/services.**

For the SIH presentation, use the phrase "state-level digital land-record services" rather than claiming Bhulekh is a single national application.

---

# 7. Existing Ecosystem

A simplified view is:

```text
                    LAND GOVERNANCE ECOSYSTEM
                              |
        +---------------------+---------------------+
        |                     |                     |
        v                     v                     v
     DILRMP                NGDRS              Bhu-Naksha
        |                     |                     |
 Land-record             Property/document     Cadastral /
 modernization             registration       parcel maps
        |                     |                     |
        +---------------------+---------------------+
                              |
                       State land-record
                         services
                          (Bhulekh)
                              |
                              v
                  Other relevant information
                  - Land use
                  - Master plans
                  - Restrictions
                  - Building permissions
                  - Property tax
                  - Utilities
```

---

# 8. Gap Analysis

## What already exists?

Government initiatives already provide important capabilities:

| Existing initiative | Main capability |
|---|---|
| DILRMP | Land-record modernization and integration programme |
| NGDRS | Property/document registration |
| Bhu-Naksha | Cadastral/parcel map management |
| State land-record portals | Citizen access to land records and related services |

## What should our solution NOT claim?

Avoid statements such as:

- "There are no digital land records."
- "NGDRS has no land-record integration."
- "Bhu-Naksha does not exist."
- "All government land systems are completely disconnected."

These statements are too broad and can be challenged by judges.

## Potential gap for SIH 26014

The stronger opportunity is:

### Parcel-centric integration and unified experience

Instead of making citizens or officials think in terms of separate systems, the platform can organize relevant information around a common land parcel.

Example:

```text
                    SEARCH PARCEL
                         |
                         v
                  Parcel / Khasra
                         |
        +----------------+----------------+
        |                |                |
        v                v                v
     GIS Map           RoR           Registration
        |                |                |
        +----------------+----------------+
                         |
                         v
                  Other context
             Land use / restrictions /
             planning / tax / utilities
                         |
                         v
                  Decision support
                         |
                         v
              Authorized human review
```

The exact data sources and integrations would depend on authorized APIs, data-sharing arrangements and government policies.

---

# 9. AI / Decision Support

AI should be positioned as **decision support**, not as a legal authority.

## Example

Suppose:

- RoR records area = 2.5 hectares
- GIS-derived parcel area = 2.1 hectares

The platform can produce:

> Potential area mismatch — requires authorized officer verification.

It should NOT produce:

> Ownership is invalid.

Similarly, the system can flag potential duplicate/conflicting information for review.

### Principle

**AI flags potential issues; authorized officials make the final legal/administrative decision.**

---

# 10. Proposed Solution Positioning

The proposed platform can be described as:

> A GIS-based, parcel-centric integration layer that brings relevant authorized land information into a unified view for citizens and government officials, while providing decision-support capabilities such as inconsistency/anomaly flagging.

## High-level architecture

```text
Existing authorized sources
(DILRMP / state land records / Bhu-Naksha /
 NGDRS / other relevant sources)
              |
              v
     API / Data Exchange Layer
              |
              v
      Data Normalization
              |
              v
     Parcel-Centric Data Layer
              |
        +-----+-----+
        |           |
        v           v
      GIS       Unified Records
        |           |
        +-----+-----+
              |
              v
       AI / Rule Engine
              |
              v
     Potential Anomaly Flags
              |
       +------+------+
       |             |
       v             v
    Citizen       Officer /
     Portal       Registrar Dashboard
```

---

# 11. Prototype vs Production

If the hackathon prototype uses synthetic/mock data, state this clearly:

> The prototype demonstrates the integration concept using representative/synthetic data. A production deployment would connect to authorized government APIs and data sources subject to applicable access, security, privacy and data-sharing policies.

Do not claim access to real government databases unless the team actually has authorized access.

---

# 12. Key Stakeholder Value

## Citizen
- Easier access to relevant parcel information
- Less need to understand multiple government systems
- Better transparency
- GIS-based understanding of parcel location/boundaries

## Revenue Officer
- Unified parcel view
- Easier comparison of relevant records
- Potential inconsistency/anomaly alerts
- Better decision support

## Registrar
- Parcel-linked context during registration-related verification
- Better visibility of relevant land information
- Decision support without replacing the registration workflow

## Government
- Better interoperability
- Better land-governance visibility
- Support for planning
- Reduced manual comparison effort
- Better data-driven governance

---

# 13. Core Gap Statement

> **Existing government initiatives already digitize and modernize important parts of land governance. The opportunity for our solution is to organize relevant information around the land parcel and provide a unified GIS-enabled experience across authorized sources, supported by decision-support and consistency-checking capabilities.**

---

# 14. One-Minute Pitch

> Land information in India is already being digitized through initiatives such as DILRMP, NGDRS, Bhu-Naksha and state land-record portals. Our solution does not aim to replace these systems. Instead, we propose a parcel-centric GIS integration layer that brings relevant spatial, textual, registration and other authorized land information together into a unified view. Citizens can understand a parcel more easily, while revenue officers and registrars can get better context and potential inconsistency alerts. AI is used only as decision support, while final legal and administrative decisions remain with authorized officials. This can improve transparency, reduce manual verification effort and support more integrated land governance.

---

# 15. Quick Viva Questions

### Q1. What is DILRMP?
DILRMP is the Government of India's programme for modernization and digitization of land records and related land information systems.

### Q2. What is NGDRS?
NGDRS is a generic system for property/document registration.

### Q3. What is Bhu-Naksha?
Bhu-Naksha is a cadastral/parcel map management solution.

### Q4. What is Bhulekh?
Bhulekh commonly refers to state-level digital land-record access/services.

### Q5. What is RoR?
Record of Rights is primarily textual information about rights/interests associated with a land parcel.

### Q6. What is a cadastral map?
A map showing land parcels and their boundaries.

### Q7. What is the gap in existing systems?
The opportunity is to provide a unified, parcel-centric GIS experience across relevant authorized information sources rather than simply creating another standalone record system.

### Q8. Will AI make the final ownership decision?
No. AI provides decision support/flags; authorized officials make the final legal or administrative decision.

### Q9. What is the main innovation?
A parcel-centric GIS integration layer and unified experience across relevant land information.

### Q10. Will our prototype access government databases?
Only if authorized. Otherwise the prototype should use representative/synthetic data to demonstrate the concept.

---

# 16. Official References

1. Department of Land Resources — DILRMP:
https://dolr.gov.in/en/programmes-schemes/dilrmp-2/

2. DILRMP 3.0 Operational Guidelines (2026–2031):
https://dolr.gov.in/en/document/digital-india-land-records-modernization-programmedilrmp-3-0-operational-guidelines-2026-2031/

3. NGDRS:
https://ngdrs.gov.in/NGDRS_Website/about-ngdrs.php

4. Bhu-Naksha:
https://www.bhunaksha.nic.in/bhunaksha/index.jsp

5. Punjab Land Records:
https://jamabandi.punjab.gov.in/

---

## Research Status

**Completed:** Step 1 — Deep-dive domain research

**Next:** Step 2 — Define 2–3 user personas (Citizen, Revenue Officer, Registrar)
