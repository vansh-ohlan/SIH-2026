# Bhu Setu — 3-Minute Pitch Script

**Opening:**  
“Land information is not limited to one record. Ownership records, parcel maps, registration, planning, taxation and other information can exist across different systems and departments. The challenge is making these pieces useful together around the land parcel.”

**Problem:**  
“Citizens and officials may need information from multiple services. Differences in systems, formats and workflows can make verification harder and create repeated effort.”

**Solution:**  
“Our solution is Bhu Setu, an integrated GIS-based digital public infrastructure prototype. Bhu Setu makes the land parcel the common context. A user selects a parcel on the map and gets a unified view of relevant authorized information such as land records, registration and planning context.”

**Architecture + AI:**  
“Different sources connect through APIs or data exchange into an integration and normalization layer. A common parcel-centric model connects the information. On top of this, Bhu Setu can provide decision support. For example, if the GIS area and record area differ beyond a configured tolerance, the system flags the parcel for review. AI does not make legal ownership decisions.”

**Demo:**  
“We search a parcel, select it on the GIS map, open its profile, inspect linked records, demonstrate an anomaly flag and then show the appropriate service or officer workflow.”

**Impact:**  
“For citizens, Bhu Setu means simpler and more transparent access. For officials, it means better parcel context and faster verification. For government, it provides an interoperability-oriented foundation that can scale using configurable state adapters.”

**Closing:**  
“Bhu Setu does not rebuild every existing land system. It connects the right information around the parcel — making land governance more accessible, transparent and decision-ready.”
