# Bhu Setu — Judge Q&A

### Q1. DILRMP, NGDRS and Bhu-Naksha already exist. What is new?
**Answer:** Bhu Setu does not replace these systems. They already digitize important parts of land governance. Bhu Setu focuses on a parcel-centric integration layer and unified GIS experience that brings relevant authorized information together and supports cross-record verification.

### Q2. How will Bhu Setu work across different states?
**Answer:** We use a common parcel-centric schema with state-specific adapters. Each adapter maps local field names, formats and units into the common structure. This makes the architecture configurable rather than assuming every state uses the same database.

### Q3. Can Bhu Setu use AI to decide legal ownership?
**Answer:** No. AI is only decision support. It can flag anomalies such as area mismatches or duplicate-looking records. Final legal verification and decisions remain with authorized government officials.

### Bonus Q4. Where will real government data come from?
**Answer:** The prototype can demonstrate the concept using mock/sample datasets. In production, Bhu Setu would connect only through authorized APIs, data-sharing arrangements and role-based access controls.

### Bonus Q5. What if two systems contain conflicting information?
**Answer:** Bhu Setu should not silently overwrite either source. It should display the source and timestamp, flag the inconsistency and route it to the appropriate authorized workflow for verification.
