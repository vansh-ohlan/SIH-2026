# SIH 26014 — Gap Analysis

## Existing vs Proposed

| Area | Existing ecosystem | Proposed platform |
|---|---|---|
| Land records | DILRMP/state land-record systems | Unified parcel-centric view |
| Registration | NGDRS and state registration systems | Parcel-linked context |
| Parcel maps | Bhu-Naksha/state GIS/cadastral systems | GIS-first unified experience |
| Citizen access | State-specific services | Simpler cross-information experience |
| Cross-record comparison | Depends on available integrations/workflows | Consistency/anomaly support |
| Planning context | May exist in other departments/systems | Bring relevant authorized context into parcel view |
| AI | Not the main purpose of these systems | Decision-support / anomaly flagging |
| Legal decision | Government officials | Remains with authorized officials |

## Core gap

The project should focus on **integration, interoperability, parcel-centric visualization and decision support**, rather than basic digitization.

## Important positioning

The proposal complements existing systems rather than replacing them.
