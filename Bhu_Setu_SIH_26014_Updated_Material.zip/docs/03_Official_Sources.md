# Official Sources

## Department of Land Resources (DoLR)

### DILRMP
https://dolr.gov.in/en/programmes-schemes/dilrmp-2/

### DILRMP 3.0 Operational Guidelines (2026–2031)
https://dolr.gov.in/en/document/digital-india-land-records-modernization-programmedilrmp-3-0-operational-guidelines-2026-2031/

## NGDRS

https://ngdrs.gov.in/NGDRS_Website/about-ngdrs.php

## Bhu-Naksha

https://www.bhunaksha.nic.in/bhunaksha/index.jsp

## Punjab Land Records

https://jamabandi.punjab.gov.in/

## Note

These links are official government portals used for domain research. Information and portal functionality may change over time.
