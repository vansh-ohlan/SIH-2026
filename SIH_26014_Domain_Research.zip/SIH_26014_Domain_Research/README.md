# SIH 26014 — Domain Research

## Problem Statement
**An Integrated GIS-based Digital Public Infrastructure for Land Governance**

This folder contains the Domain Research work prepared for the Domain Researcher + Pitch/Business Lead role.

## Research completed
- DILRMP / DILRMP 3.0
- NGDRS
- Bhu-Naksha
- Bhulekh / state land-record services
- Existing ecosystem and gap analysis
- Proposed value of a parcel-centric GIS integration layer

## Key conclusion
Existing government initiatives already digitize and modernize important parts of land governance. The proposed solution should not claim to replace them. Instead, the opportunity is to provide a parcel-centric GIS integration layer that can bring relevant authorized spatial, textual, registration and planning information into a unified experience, with decision-support alerts.

See `01_Domain_Research.md` for the complete research.
